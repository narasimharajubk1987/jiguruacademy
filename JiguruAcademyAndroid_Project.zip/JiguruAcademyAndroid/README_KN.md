# Jiguru Academy Android App (WebView Wrapper)

ಈ ಪ್ರಾಜೆಕ್ಟ್ ನೀವು ಒದಗಿಸಿದ `Jiguru_Payment_App_Vehicle_Passbook_Payment_Fix-1.html` ಫೈಲ್ ಅನ್ನು Android ಆಪ್ ಒಳಗೆ ತೆರೆಯುತ್ತದೆ. UPI/PhonePe ಕಾರ್ಯವನ್ನು ಹೊಸದಾಗಿ ಸೇರಿಸಿಲ್ಲ; HTML‌ನಲ್ಲಿರುವ ಪ್ರಸ್ತುತ ಕಾರ್ಯವಿಧಾನ ಹಾಗೆಯೇ ಇರುತ್ತದೆ.

## APK ನಿರ್ಮಿಸುವುದು
1. Android Studio ಇರುವ ಕಂಪ್ಯೂಟರ್‌ನಲ್ಲಿ ಈ ZIP ಅನ್ನು Extract ಮಾಡಿ.
2. Android Studio → Open → `JiguruAcademyAndroid` ಫೋಲ್ಡರ್ ಆಯ್ಕೆಮಾಡಿ.
3. Gradle sync ಪೂರ್ಣಗೊಳ್ಳಲು ಬಿಡಿ; ಅಗತ್ಯವಿದ್ದರೆ Android SDK Platform 35 ಮತ್ತು JDK 17 ಇನ್‌ಸ್ಟಾಲ್ ಮಾಡಿ.
4. Build → Build Bundle(s) / APK(s) → Build APK(s).
5. Debug APK ಸಾಮಾನ್ಯವಾಗಿ `app/build/outputs/apk/debug/app-debug.apk` ನಲ್ಲಿ ಸಿಗುತ್ತದೆ.

## ಗಮನಿಸಿ
- ಈ ZIP source project; ಇಲ್ಲಿ ನೇರವಾಗಿ APK compile ಆಗಿಲ್ಲ.
- Supabase URL/key HTML‌ನಲ್ಲೇ ಇರುವುದರಿಂದ, ಡೇಟಾಬೇಸ್ RLS ನೀತಿಗಳು ಸರಿಯಾಗಿರುವುದು ಅತ್ಯಗತ್ಯ. Publishable key ಮಾತ್ರ client app‌ನಲ್ಲಿ ಇರಬೇಕು; service-role/secret key ಎಂದಿಗೂ ಸೇರಿಸಬೇಡಿ.
- Android APK ಒಳಗಿನ WebView ಮೂಲಕ Supabase‌ಗೆ ಸಂಪರ್ಕಿಸಲು Internet permission ಸೇರಿಸಲಾಗಿದೆ.
- ಪ್ರಸ್ತುತ HTML‌ನಲ್ಲಿ ಇರುವ login, data, and payment behaviors are not redesigned here. Actual device and Supabase testing is required before production use.
